"""This __init__ file will be called once data is generated in webhook and it creates trigger."""
import json
import logging
import os
from RubrikAnomalyEvent import AzureSentinel
from RubrikAnomalyEvent import RubrikException
import azure.functions as func

# fetch data from os environment
sentinel_customer_id = os.environ.get("WorkspaceID")
sentinel_shared_key = os.environ.get("WorkspaceKey")
sentinel_log_type = os.environ.get("Anomalies_table_name")


def main(request: func.HttpRequest) -> func.HttpResponse:
    """
    start the execution.

    Args:
        request (func.HttpRequest): To get data from request body pushed by webhook

    Returns:
        func.HttpResponse: Status of Http request process (successful/failed).
    """

    logging.info("Rubrik Anomaly: Python HTTP trigger function processed a request.")
    try:
        webhook_data = request.get_json()
    except ValueError as ve:
        logging.error("Error occurred in RubrikAnomalyEvent: {}".format(ve))
    else:
        if webhook_data:
            body = json.dumps(webhook_data)
            logging.info("Got data of Anomaly event via webhook.")
            try:
                logging.info("Try to posting the webhook data from RubrikAnomalyEvent.")
                azuresentinel = AzureSentinel()
                status_code = azuresentinel.post_data(
                    sentinel_customer_id,
                    sentinel_shared_key,
                    body,
                    sentinel_log_type,
                )
            except RubrikException as err:
                logging.error(err)
            else:
                if status_code >= 200 and status_code <= 299:
                    return func.HttpResponse(
                        "Data posted successfully to log analytics from RubrikAnomalyEvent."
                    )
                return func.HttpResponse(
                    "Failed to post data into sentinel from RubrikAnomalyEvent."
                )
